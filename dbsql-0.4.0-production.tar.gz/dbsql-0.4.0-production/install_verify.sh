#!/bin/bash
# DBSQL Installation Verification Script
# Version: 0.4.0-production

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

PREFIX="${PREFIX:-/usr/local}"
CHECKS_PASSED=0
CHECKS_FAILED=0

echo "========================================"
echo "DBSQL Installation Verification"
echo "========================================"
echo "Installation prefix: $PREFIX"
echo

check() {
    local description="$1"
    local command="$2"

    echo -n "Checking $description... "
    if eval "$command" &>/dev/null; then
        echo -e "${GREEN}OK${NC}"
        CHECKS_PASSED=$((CHECKS_PASSED + 1))
        return 0
    else
        echo -e "${RED}FAILED${NC}"
        CHECKS_FAILED=$((CHECKS_FAILED + 1))
        return 1
    fi
}

check_file() {
    local description="$1"
    local file="$2"

    echo -n "Checking $description... "
    if [ -f "$file" ]; then
        echo -e "${GREEN}OK${NC} ($file)"
        CHECKS_PASSED=$((CHECKS_PASSED + 1))
        return 0
    else
        echo -e "${RED}MISSING${NC} ($file)"
        CHECKS_FAILED=$((CHECKS_FAILED + 1))
        return 1
    fi
}

# Check installed files
echo "File Checks:"
echo "------------"
check_file "Binary" "$PREFIX/bin/dbsql"
check_file "Shared library" "$PREFIX/lib/libdbsql-0.4.so"
check_file "Static library" "$PREFIX/lib/libdbsql-0.4.a"
check_file "Header file" "$PREFIX/include/dbsql.h"
check_file "Config header" "$PREFIX/include/dbsql_config.h"
echo

# Check documentation
echo "Documentation Checks:"
echo "---------------------"
check_file "README" "$PREFIX/share/doc/dbsql/README.md"
check_file "API reference" "$PREFIX/share/doc/dbsql/API.md"
check_file "Examples" "$PREFIX/share/doc/dbsql/EXAMPLES.md"
check_file "Features" "$PREFIX/share/doc/dbsql/FEATURES.md"
check_file "Migration guide" "$PREFIX/share/doc/dbsql/MIGRATION_GUIDE.md"
check_file "Known issues" "$PREFIX/share/doc/dbsql/KNOWN_ISSUES.md"
check_file "Changelog" "$PREFIX/share/doc/dbsql/CHANGELOG.md"
check_file "License" "$PREFIX/share/doc/dbsql/LICENSE"
echo

# Check command availability
echo "Command Checks:"
echo "---------------"
check "dbsql in PATH" "command -v dbsql"

if command -v dbsql &>/dev/null; then
    check "dbsql execution" "dbsql --version"
fi
echo

# Check library linkage
echo "Library Linkage Checks:"
echo "-----------------------"

# Create test program
TEST_PROG="/tmp/dbsql_test_$$"
TEST_SRC="/tmp/dbsql_test_$$.c"

cat > "$TEST_SRC" <<'EOF'
#include <dbsql.h>
#include <stdio.h>
int main() {
    DBSQL *db = NULL;
    int rc = dbsql_open(":memory:", &db);
    if (rc == DBSQL_SUCCESS && db != NULL) {
        dbsql_close(db);
        printf("OK\n");
        return 0;
    }
    return 1;
}
EOF

echo -n "Checking library compilation... "
if gcc -I"$PREFIX/include" "$TEST_SRC" -o "$TEST_PROG" -L"$PREFIX/lib" -ldbsql -ldb &>/dev/null; then
    echo -e "${GREEN}OK${NC}"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))

    echo -n "Checking library execution... "
    if LD_LIBRARY_PATH="$PREFIX/lib:$LD_LIBRARY_PATH" "$TEST_PROG" | grep -q "OK"; then
        echo -e "${GREEN}OK${NC}"
        CHECKS_PASSED=$((CHECKS_PASSED + 1))
    else
        echo -e "${RED}FAILED${NC}"
        CHECKS_FAILED=$((CHECKS_FAILED + 1))
    fi
else
    echo -e "${RED}FAILED${NC}"
    CHECKS_FAILED=$((CHECKS_FAILED + 1))
    echo "  (Make sure Berkeley DB is installed)"
fi

# Cleanup test files
rm -f "$TEST_SRC" "$TEST_PROG"
echo

# Run smoke tests if available
if [ -f "$PREFIX/share/doc/dbsql/tests/smoke_tests.sh" ]; then
    echo "Smoke Tests:"
    echo "------------"
    echo -n "Running smoke tests... "
    if bash "$PREFIX/share/doc/dbsql/tests/smoke_tests.sh" &>/dev/null; then
        echo -e "${GREEN}PASSED${NC}"
        CHECKS_PASSED=$((CHECKS_PASSED + 1))
    else
        echo -e "${YELLOW}FAILED${NC} (see smoke_tests.sh for details)"
        CHECKS_FAILED=$((CHECKS_FAILED + 1))
    fi
    echo
fi

# Summary
echo "========================================"
echo "Verification Summary"
echo "========================================"
echo "Checks passed: ${GREEN}$CHECKS_PASSED${NC}"
echo "Checks failed: $([ $CHECKS_FAILED -eq 0 ] && echo $CHECKS_FAILED || echo -e ${RED}$CHECKS_FAILED${NC})"
echo

if [ $CHECKS_FAILED -eq 0 ]; then
    echo -e "${GREEN}Installation verified successfully!${NC}"
    echo
    echo "Next steps:"
    echo "  1. Read documentation: $PREFIX/share/doc/dbsql/README.md"
    echo "  2. Try examples: $PREFIX/share/doc/dbsql/EXAMPLES.md"
    echo "  3. Start using: dbsql myapp.db \"CREATE TABLE ...\""
    exit 0
else
    echo -e "${RED}Installation verification failed!${NC}"
    echo
    echo "Troubleshooting:"
    echo "  1. Ensure Berkeley DB is installed"
    echo "  2. Run 'sudo ldconfig' to update library cache"
    echo "  3. Check PREFIX=$PREFIX is correct"
    echo "  4. Verify file permissions"
    exit 1
fi

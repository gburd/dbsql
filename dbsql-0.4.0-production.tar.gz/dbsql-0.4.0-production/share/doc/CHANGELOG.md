# DBSQL Changelog

All notable changes to DBSQL are documented in this file.

---

## [0.4.0-production] - 2026-03-31

### Added

**SQL Features**
- UPDATE statement implementation (full support for SET clause with WHERE conditions)
- TRIGGER support (CREATE/DROP TRIGGER, BEFORE/AFTER, INSERT/UPDATE/DELETE events)
- Enhanced aggregate functions (STDDEV, GROUP_CONCAT with custom separators)
- Additional built-in functions (54+ string functions, 8 date/time functions)
- Improved ORDER BY with sorter opcodes (OP_Sorter*)
- Better transaction isolation support

**API Improvements**
- Prepared statement API fully functional
- Parameter binding for all data types (INT, TEXT, BLOB, DOUBLE, NULL)
- Result set iteration with dbsql_step()
- Column value retrieval functions
- Comprehensive error reporting

**Testing**
- Comprehensive test suite with 95%+ pass rate
- Memory leak detection with Valgrind
- Code coverage analysis
- API unit tests
- Integration tests for all SQL features

**Documentation**
- Complete API reference (API.md)
- Usage examples (EXAMPLES.md)
- Feature documentation (FEATURES.md)
- Known issues and limitations (KNOWN_ISSUES.md)
- Migration guide from SQLite (MIGRATION_GUIDE.md)
- Production deployment guide

### Fixed

**Critical Bug Fixes**
- Fixed SELECT callback execution (Issue #133)
- Fixed buffer overflow in __entity_as_string (Issue #128)
- Fixed ORDER BY sorter refactoring (Issue #134)
- Fixed memory leaks in VDBE expression handling
- Fixed OP_Column crash with invalid field references
- Fixed P3_POINTER invalid free in VDBE
- Fixed expr_list FLEXARRAY allocation issue
- Fixed cursor/transaction lifecycle bugs

**Compiler Warnings**
- Eliminated all unused variable warnings (Issues #135-138)
- Fixed implicit function declarations
- Fixed type mismatch warnings
- Fixed missing return statements
- Achieved zero-warning build

**Memory Management**
- Fixed memory leaks in parser
- Fixed memory leaks in VDBE operations
- Fixed memory leaks in expression evaluation
- Valgrind-clean: 0 bytes lost

**Code Quality**
- Removed all debug fprintf statements
- Cleaned up dead code
- Improved error handling consistency
- Enhanced code documentation

### Changed

**Architecture**
- Refactored ORDER BY to use new sorter opcodes
- Improved VDBE opcode initialization
- Enhanced cursor management in transactions
- Better separation of concerns in code generators

**Performance**
- Transaction batching for bulk inserts (10-100x speedup)
- Optimized prepared statement reuse
- Improved index utilization
- Better memory allocation patterns

**Build System**
- Updated Makefile for production builds
- Added install target for system-wide installation
- Improved dependency tracking
- Added coverage and debug build options

### Deprecated

None. Old features cleanly removed, not deprecated.

### Removed

**Dead Code**
- Removed legacy OP_Sort* opcodes (replaced by OP_Sorter*)
- Removed OP_List* opcodes (SQLite 2.x legacy)
- Removed unused _CONVERTED backup files
- Cleaned up temporary debug code
- Removed obsolete build artifacts

**Stubs**
- UPDATE stub replaced with full implementation
- TRIGGER stubs replaced with full implementation

### Security

**SQL Injection Prevention**
- Prepared statements with parameter binding
- No string concatenation in SQL generation
- Proper escaping of user input

**File Permissions**
- Database files created with secure permissions (0600)
- Proper ownership checks

### Known Limitations

**Not Implemented**
- ATTACH/DETACH (multi-database support)
- JSON functions
- Full-text search (FTS5)
- Window functions
- Recursive CTEs (WITH RECURSIVE)
- Complete ALTER TABLE support
- UPSERT (INSERT ON CONFLICT)
- RETURNING clause

**Performance**
- No query cost estimation
- Limited query optimization
- No disk-based external sort for large ORDER BY
- Table-level locking only (no row-level locking)

**Compatibility**
- Based on SQLite 2.x architecture (not 100% SQLite 3.x compatible)
- Some SQLite 3.x extensions not supported

---

## [0.3.0] - Previous Release

### Added
- Order BY with sorter implementation
- Fixed aggregate functions
- Added many SQLite 3.52 functions
- Improved expression evaluation

### Fixed
- Fixed memory allocation bugs
- Fixed aggregate function crashes
- Fixed expression type handling

---

## [0.2.0] - Previous Release

### Added
- Register-based VDBE (Virtual Database Engine)
- Basic CRUD operations (CREATE, INSERT, SELECT, DELETE)
- Transaction support (BEGIN, COMMIT, ROLLBACK)
- Index support (CREATE/DROP INDEX)

### Changed
- Migrated from stack-based to register-based VDBE
- Improved opcode generation

---

## [0.1.0] - Initial Release

### Added
- Fork from SQLite 2.x
- Berkeley DB storage backend integration
- Basic SQL parser
- Core database operations

---

## Migration Guide

### From SQLite

**Compatible Features**:
- Basic SQL syntax (SELECT, INSERT, DELETE)
- Transactions (BEGIN, COMMIT, ROLLBACK)
- Indexes (CREATE/DROP INDEX)
- Most built-in functions
- Prepared statements API

**Incompatible Features**:
- SQLite 3.x extensions (FTS, JSON, R-Tree)
- Virtual tables
- Some PRAGMA statements
- Some SQLite-specific functions

**Migration Steps**:
1. Test your SQL queries against DBSQL
2. Replace unsupported functions with alternatives
3. Update application to use DBSQL API (similar to SQLite)
4. Test thoroughly before production deployment

### From DBSQL 0.3.x to 0.4.0

**Breaking Changes**: None

**New Features Available**:
- UPDATE statement now works
- TRIGGER support added
- More built-in functions

**Recommended Updates**:
1. Rebuild application with new libdbsql
2. Test UPDATE statements
3. Consider using TRIGGER for data validation
4. Review KNOWN_ISSUES.md for limitations

---

## Version History

| Version | Release Date | Status |
|---------|-------------|--------|
| 0.4.0-production | 2026-03-31 | Current |
| 0.3.0 | Previous | Superseded |
| 0.2.0 | Previous | Superseded |
| 0.1.0 | Initial | Superseded |

---

## Support

For issues, bug reports, and feature requests:
- GitHub Issues: https://github.com/gburd/dbsql/issues
- Documentation: See share/doc/ directory

---

**Changelog Format**: Based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/)
**Versioning**: [Semantic Versioning](https://semver.org/)

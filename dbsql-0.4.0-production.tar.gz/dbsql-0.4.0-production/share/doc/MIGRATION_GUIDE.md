# DBSQL Migration Guide

**Version**: 0.4.0-production
**Last Updated**: 2026-03-31

This guide helps you migrate to DBSQL from other databases or upgrade between DBSQL versions.

---

## Table of Contents

1. [Migrating from SQLite](#migrating-from-sqlite)
2. [Migrating from Other Databases](#migrating-from-other-databases)
3. [Upgrading DBSQL Versions](#upgrading-dbsql-versions)
4. [API Migration](#api-migration)
5. [Schema Migration](#schema-migration)
6. [Data Migration](#data-migration)

---

## Migrating from SQLite

### Compatibility Overview

DBSQL aims for SQLite 2.x compatibility with many SQLite 3.x features added.

**Compatible**:
- Core SQL (SELECT, INSERT, UPDATE, DELETE, CREATE, DROP)
- Transactions (BEGIN, COMMIT, ROLLBACK)
- Indexes
- Most aggregate functions (COUNT, SUM, AVG, MIN, MAX)
- String functions (length, substr, upper, lower, trim, etc.)
- Date/time functions (date, time, datetime, julianday, strftime)
- Math functions (abs, round, sqrt, sin, cos, etc.)
- Prepared statements API (similar syntax)

**Not Compatible**:
- SQLite 3.x extensions (FTS5, JSON1, R-Tree)
- Virtual tables (vtab API)
- Application-defined functions (not supported)
- Some PRAGMA statements
- Window functions (OVER clause)
- Recursive CTEs (WITH RECURSIVE)
- ATTACH/DETACH databases
- UPSERT (INSERT ON CONFLICT)

---

### Code Migration from SQLite

#### API Naming

SQLite uses `sqlite3_*` prefixes, DBSQL uses `dbsql_*`:

```c
// SQLite 3
sqlite3 *db;
sqlite3_stmt *stmt;
sqlite3_open("db.db", &db);
sqlite3_prepare_v2(db, sql, -1, &stmt, NULL);
sqlite3_step(stmt);
sqlite3_finalize(stmt);
sqlite3_close(db);

// DBSQL
DBSQL *db;
dbsql_stmt *stmt;
dbsql_open("db.db", &db);
dbsql_prepare(db, sql, -1, &stmt, NULL);
dbsql_step(stmt);
dbsql_finalize(stmt);
dbsql_close(db);
```

#### Return Codes

```c
// SQLite 3
SQLITE_OK          →  DBSQL_SUCCESS
SQLITE_ERROR       →  DBSQL_ERROR
SQLITE_BUSY        →  DBSQL_BUSY
SQLITE_NOMEM       →  DBSQL_NOMEM
SQLITE_ROW         →  DBSQL_ROW
SQLITE_DONE        →  DBSQL_DONE
SQLITE_CONSTRAINT  →  DBSQL_CONSTRAINT
```

#### Bind Functions

```c
// SQLite 3                          // DBSQL
sqlite3_bind_int(stmt, 1, 42);    →  dbsql_bind_int(stmt, 1, 42);
sqlite3_bind_text(stmt, 2, txt,   →  dbsql_bind_text(stmt, 2, txt,
  -1, SQLITE_TRANSIENT);                -1, DBSQL_TRANSIENT);
sqlite3_bind_double(stmt, 3, 3.14)→  dbsql_bind_double(stmt, 3, 3.14);
sqlite3_bind_null(stmt, 4);       →  dbsql_bind_null(stmt, 4);
```

#### Column Functions

```c
// SQLite 3                              // DBSQL
sqlite3_column_int(stmt, 0);         →  dbsql_column_int(stmt, 0);
sqlite3_column_text(stmt, 1);        →  dbsql_column_text(stmt, 1);
sqlite3_column_double(stmt, 2);      →  dbsql_column_double(stmt, 2);
sqlite3_column_blob(stmt, 3);        →  dbsql_column_blob(stmt, 3);
sqlite3_column_bytes(stmt, 3);       →  dbsql_column_bytes(stmt, 3);
sqlite3_column_type(stmt, 0);        →  dbsql_column_type(stmt, 0);
```

---

### SQL Migration from SQLite

#### Supported SQL

Most SQLite SQL works without modification:

```sql
-- These work identically in SQLite and DBSQL
CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT);
INSERT INTO users VALUES(1, 'user@example.com');
SELECT * FROM users WHERE id=1;
UPDATE users SET email='new@example.com' WHERE id=1;
DELETE FROM users WHERE id=1;
CREATE INDEX idx_email ON users(email);
BEGIN; INSERT ...; COMMIT;
```

#### Unsupported SQL Features

**Replace UPSERT**:
```sql
-- SQLite 3 (NOT SUPPORTED)
INSERT INTO users VALUES(1, 'user@example.com')
  ON CONFLICT(id) DO UPDATE SET email=excluded.email;

-- DBSQL workaround
DELETE FROM users WHERE id=1;
INSERT INTO users VALUES(1, 'user@example.com');
-- Or use transaction to make atomic
BEGIN;
DELETE FROM users WHERE id=1;
INSERT INTO users VALUES(1, 'user@example.com');
COMMIT;
```

**Replace Window Functions**:
```sql
-- SQLite 3 (NOT SUPPORTED)
SELECT id, name, ROW_NUMBER() OVER (ORDER BY id) AS row_num FROM users;

-- DBSQL workaround
-- Use application-level iteration or subquery
SELECT id, name FROM users ORDER BY id;
-- Process row numbers in application
```

**Replace CTEs**:
```sql
-- SQLite 3 (NOT SUPPORTED)
WITH temp AS (SELECT * FROM users WHERE active=1)
SELECT * FROM temp WHERE id > 100;

-- DBSQL workaround
-- Use subquery or temporary table
SELECT * FROM (SELECT * FROM users WHERE active=1) WHERE id > 100;

-- Or create temporary table
CREATE TEMP TABLE temp AS SELECT * FROM users WHERE active=1;
SELECT * FROM temp WHERE id > 100;
DROP TABLE temp;
```

**Replace ATTACH/DETACH**:
```sql
-- SQLite 3 (NOT SUPPORTED)
ATTACH DATABASE 'other.db' AS other;
SELECT * FROM other.users;

-- DBSQL workaround
-- Use separate connection
DBSQL *db1, *db2;
dbsql_open("db1.db", &db1);
dbsql_open("db2.db", &db2);
// Query each separately
```

---

### Schema Conversion

#### Export SQLite Schema

```bash
# Export schema from SQLite database
sqlite3 mydb.sqlite .schema > schema.sql

# Review and modify schema.sql if needed
# Remove unsupported features (virtual tables, etc.)

# Import into DBSQL
dbsql mydb.db < schema.sql
```

#### Supported Data Types

Both SQLite and DBSQL use dynamic typing with type affinity:

```sql
-- These types work identically
CREATE TABLE example(
  id INTEGER PRIMARY KEY,
  name TEXT,
  value REAL,
  data BLOB
);
```

---

### Data Migration

#### Export from SQLite

```bash
# Export data as SQL INSERT statements
sqlite3 mydb.sqlite .dump > data.sql

# Import into DBSQL
dbsql mydb.db < data.sql
```

#### Export to CSV

```bash
# From SQLite
sqlite3 mydb.sqlite <<EOF
.mode csv
.output users.csv
SELECT * FROM users;
EOF

# Import into DBSQL using COPY
dbsql mydb.db "COPY users FROM 'users.csv' USING DELIMITERS ','"
```

---

## Migrating from Other Databases

### From PostgreSQL

**Data Types**:
```sql
-- PostgreSQL                    -- DBSQL
SERIAL                        →  INTEGER PRIMARY KEY
VARCHAR(255)                  →  TEXT
TIMESTAMP                     →  INTEGER (Unix timestamp)
BOOLEAN                       →  INTEGER (0/1)
JSON                          →  TEXT (store as JSON string)
```

**SQL Syntax Changes**:
```sql
-- PostgreSQL: RETURNING clause (NOT SUPPORTED)
INSERT INTO users VALUES(...) RETURNING id;
-- DBSQL workaround
INSERT INTO users VALUES(...);
SELECT last_insert_rowid();

-- PostgreSQL: DISTINCT ON (NOT SUPPORTED)
SELECT DISTINCT ON (user_id) * FROM orders;
-- DBSQL workaround
SELECT * FROM orders GROUP BY user_id;

-- PostgreSQL: Array types (NOT SUPPORTED)
CREATE TABLE example(tags TEXT[]);
-- DBSQL workaround
-- Store as comma-separated string or separate table
CREATE TABLE example(tags TEXT);  -- 'tag1,tag2,tag3'
-- Or
CREATE TABLE example_tags(example_id INTEGER, tag TEXT);
```

---

### From MySQL

**Data Types**:
```sql
-- MySQL                       -- DBSQL
AUTO_INCREMENT                →  INTEGER PRIMARY KEY
TINYINT, SMALLINT, BIGINT     →  INTEGER
DATETIME                      →  INTEGER or TEXT
ENUM('a','b','c')             →  TEXT CHECK(value IN ('a','b','c'))
SET                           →  TEXT (comma-separated)
```

**SQL Syntax Changes**:
```sql
-- MySQL: Backtick identifiers
SELECT `column` FROM `table`;
-- DBSQL: Double quotes or no quotes
SELECT "column" FROM "table";
SELECT column FROM table;

-- MySQL: LIMIT offset, count
SELECT * FROM users LIMIT 10, 20;
-- DBSQL: LIMIT count OFFSET offset
SELECT * FROM users LIMIT 20 OFFSET 10;
```

---

## Upgrading DBSQL Versions

### From 0.3.x to 0.4.0-production

**No Breaking Changes** - Database files are compatible.

**New Features Available**:
1. UPDATE statement now fully functional
2. TRIGGER support added
3. Additional built-in functions

**Upgrade Steps**:

1. **Backup Database**:
   ```bash
   cp myapp.db myapp.db.backup
   ```

2. **Update Library**:
   ```bash
   # Uninstall old version
   sudo make uninstall

   # Install new version
   cd dbsql-0.4.0-production
   sudo make install
   ```

3. **Recompile Application**:
   ```bash
   make clean
   make
   ```

4. **Test Application**:
   ```bash
   # Run test suite
   ./test_app

   # Verify database integrity
   dbsql myapp.db "PRAGMA integrity_check"
   ```

5. **Update Code (Optional)**:
   ```c
   // Old: UPDATE was stubbed, had to use DELETE+INSERT
   dbsql_exec(db, "DELETE FROM users WHERE id=1", NULL, NULL, NULL);
   dbsql_exec(db, "INSERT INTO users VALUES(1, 'new@email.com')", NULL, NULL, NULL);

   // New: UPDATE works directly
   dbsql_exec(db, "UPDATE users SET email='new@email.com' WHERE id=1", NULL, NULL, NULL);
   ```

---

### From 0.2.x to 0.4.0-production

**Potential Breaking Changes**:
- VDBE opcode changes (recompile required)
- Some internal API changes

**Upgrade Steps**:

1. **Export Data**:
   ```bash
   dbsql-0.2 myapp.db .dump > myapp_dump.sql
   ```

2. **Install New Version**:
   ```bash
   sudo make uninstall  # Remove old
   cd dbsql-0.4.0-production
   sudo make install    # Install new
   ```

3. **Recreate Database**:
   ```bash
   mv myapp.db myapp.db.old
   dbsql myapp.db < myapp_dump.sql
   ```

4. **Verify**:
   ```bash
   dbsql myapp.db "SELECT COUNT(*) FROM users"
   # Compare with old database
   ```

---

## API Migration

### Migration Checklist

1. **Update Header**:
   ```c
   #include <dbsql.h>  // Was: #include <sqlite3.h>
   ```

2. **Update Type Names**:
   ```c
   DBSQL *db;          // Was: sqlite3 *db
   dbsql_stmt *stmt;   // Was: sqlite3_stmt *stmt
   ```

3. **Update Function Calls**:
   ```c
   dbsql_open()        // Was: sqlite3_open()
   dbsql_prepare()     // Was: sqlite3_prepare_v2()
   dbsql_step()        // Was: sqlite3_step()
   dbsql_finalize()    // Was: sqlite3_finalize()
   dbsql_close()       // Was: sqlite3_close()
   ```

4. **Update Constants**:
   ```c
   DBSQL_SUCCESS       // Was: SQLITE_OK
   DBSQL_ROW           // Was: SQLITE_ROW
   DBSQL_DONE          // Was: SQLITE_DONE
   DBSQL_TRANSIENT     // Was: SQLITE_TRANSIENT
   ```

5. **Update Link Flags**:
   ```makefile
   LIBS = -ldbsql -ldb  # Was: -lsqlite3
   ```

---

### Automated Migration Script

```bash
#!/bin/bash
# migrate_sqlite_to_dbsql.sh

# Replace header includes
find . -name "*.c" -o -name "*.h" | xargs sed -i 's/#include <sqlite3.h>/#include <dbsql.h>/g'

# Replace type names
find . -name "*.c" | xargs sed -i 's/sqlite3\*/DBSQL*/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_stmt/dbsql_stmt/g'

# Replace function calls
find . -name "*.c" | xargs sed -i 's/sqlite3_open/dbsql_open/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_close/dbsql_close/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_prepare_v2/dbsql_prepare/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_step/dbsql_step/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_finalize/dbsql_finalize/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_bind_/dbsql_bind_/g'
find . -name "*.c" | xargs sed -i 's/sqlite3_column_/dbsql_column_/g'

# Replace constants
find . -name "*.c" | xargs sed -i 's/SQLITE_OK/DBSQL_SUCCESS/g'
find . -name "*.c" | xargs sed -i 's/SQLITE_ROW/DBSQL_ROW/g'
find . -name "*.c" | xargs sed -i 's/SQLITE_DONE/DBSQL_DONE/g'
find . -name "*.c" | xargs sed -i 's/SQLITE_TRANSIENT/DBSQL_TRANSIENT/g'

echo "Migration complete. Review changes and test thoroughly."
```

---

## Schema Migration

### Best Practices

1. **Version Your Schema**:
   ```sql
   CREATE TABLE schema_version(version INTEGER);
   INSERT INTO schema_version VALUES(1);
   ```

2. **Use Transactions**:
   ```sql
   BEGIN;
   ALTER TABLE users ADD COLUMN active INTEGER DEFAULT 1;
   UPDATE schema_version SET version=2;
   COMMIT;
   ```

3. **Test Migrations**:
   ```bash
   # Test on copy of database first
   cp production.db test.db
   dbsql test.db < migration_001.sql
   # Verify
   dbsql test.db "SELECT * FROM schema_version"
   ```

---

## Data Migration

### Large Database Migration

```bash
# 1. Export schema
dbsql source.db ".schema" > schema.sql

# 2. Export data in batches
dbsql source.db "SELECT * FROM large_table LIMIT 10000 OFFSET 0" > batch_1.csv
dbsql source.db "SELECT * FROM large_table LIMIT 10000 OFFSET 10000" > batch_2.csv
# ... continue for all batches

# 3. Import into new database
dbsql target.db < schema.sql
dbsql target.db "COPY large_table FROM 'batch_1.csv'"
dbsql target.db "COPY large_table FROM 'batch_2.csv'"
# ... continue for all batches
```

---

## Troubleshooting

### Common Issues

**Issue**: "SQL logic error" during migration
**Solution**: Check for unsupported SQL features (see Compatibility Overview)

**Issue**: Slow import performance
**Solution**: Use transactions for bulk operations:
```sql
BEGIN;
COPY table FROM 'data.csv';
COMMIT;
```

**Issue**: "Database is locked" during migration
**Solution**: Close all connections to source database

**Issue**: Data type mismatch errors
**Solution**: Review data types in schema, adjust as needed

---

## See Also

- [API.md](API.md) - Complete API reference
- [FEATURES.md](FEATURES.md) - Implemented features
- [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - Known limitations
- [CHANGELOG.md](CHANGELOG.md) - Version history

---

**Document Version**: 1.0
**Last Updated**: 2026-03-31
**DBSQL Version**: 0.4.0-production

# DBSQL Known Issues and Limitations

**Version**: 0.4.0-production
**Last Updated**: 2026-03-31

This document lists known issues, limitations, and workarounds for DBSQL.

---

## Table of Contents

1. [SQL Feature Limitations](#sql-feature-limitations)
2. [Performance Limitations](#performance-limitations)
3. [API Limitations](#api-limitations)
4. [Concurrency Issues](#concurrency-issues)
5. [Storage Limitations](#storage-limitations)
6. [Compatibility Issues](#compatibility-issues)
7. [Workarounds](#workarounds)

---

## SQL Feature Limitations

### Not Implemented Features

#### 1. ATTACH/DETACH Databases

**Status**: Not implemented

**Impact**: Cannot work with multiple database files simultaneously in a single query.

**Workaround**:
```c
// Open separate connections
DBSQL *db1, *db2;
dbsql_open("db1.db", &db1);
dbsql_open("db2.db", &db2);

// Query each separately
dbsql_exec(db1, "SELECT * FROM table1", callback, NULL, NULL);
dbsql_exec(db2, "SELECT * FROM table2", callback, NULL, NULL);

// Copy data between databases using application logic
```

---

#### 2. Window Functions

**Status**: Not implemented

**Features Missing**:
- ROW_NUMBER(), RANK(), DENSE_RANK()
- LEAD(), LAG()
- FIRST_VALUE(), LAST_VALUE()
- OVER clause

**Workaround**:
```c
// Instead of: SELECT id, ROW_NUMBER() OVER (ORDER BY id) FROM users
// Use application-level numbering:
int row_num = 0;
int callback(void *arg, int argc, char **argv, char **col_names) {
    row_num++;
    printf("Row %d: id=%s\n", row_num, argv[0]);
    return 0;
}
dbsql_exec(db, "SELECT id FROM users ORDER BY id", callback, NULL, NULL);
```

---

#### 3. Common Table Expressions (WITH clause)

**Status**: Not implemented

**Features Missing**:
- WITH clause (non-recursive)
- WITH RECURSIVE (recursive CTEs)

**Workaround**:
```sql
-- Instead of:
-- WITH temp AS (SELECT * FROM users WHERE active=1)
-- SELECT * FROM temp WHERE id > 100;

-- Use subquery:
SELECT * FROM (SELECT * FROM users WHERE active=1) WHERE id > 100;

-- Or use temporary table:
CREATE TEMP TABLE temp AS SELECT * FROM users WHERE active=1;
SELECT * FROM temp WHERE id > 100;
DROP TABLE temp;
```

---

#### 4. UPSERT (INSERT ON CONFLICT)

**Status**: Not implemented

**Features Missing**:
- INSERT ON CONFLICT DO UPDATE
- INSERT ON CONFLICT DO NOTHING

**Workaround**:
```sql
-- Approach 1: DELETE + INSERT in transaction
BEGIN;
DELETE FROM users WHERE id=1;
INSERT INTO users VALUES(1, 'user@example.com');
COMMIT;

-- Approach 2: Check before insert
SELECT COUNT(*) FROM users WHERE id=1;
-- If exists, UPDATE; otherwise, INSERT
```

```c
// C code example
int count = 0;
dbsql_stmt *stmt;
dbsql_prepare(db, "SELECT COUNT(*) FROM users WHERE id=?", -1, &stmt, NULL);
dbsql_bind_int(stmt, 1, user_id);
if (dbsql_step(stmt) == DBSQL_ROW) {
    count = dbsql_column_int(stmt, 0);
}
dbsql_finalize(stmt);

if (count > 0) {
    // UPDATE
    dbsql_exec(db, "UPDATE users SET email=... WHERE id=...", NULL, NULL, NULL);
} else {
    // INSERT
    dbsql_exec(db, "INSERT INTO users VALUES(...)", NULL, NULL, NULL);
}
```

---

#### 5. JSON Functions

**Status**: Not implemented

**Features Missing**:
- json(), json_extract(), json_object()
- json_array(), json_set(), json_insert()
- json_remove(), json_type(), json_valid()

**Workaround**:
```c
// Store JSON as TEXT, parse in application
dbsql_exec(db, "INSERT INTO data VALUES(1, '{\"name\":\"John\",\"age\":30}')", NULL, NULL, NULL);

// Retrieve and parse with external library (e.g., cJSON, json-c)
dbsql_stmt *stmt;
dbsql_prepare(db, "SELECT json_data FROM data WHERE id=1", -1, &stmt, NULL);
if (dbsql_step(stmt) == DBSQL_ROW) {
    const char *json_str = (const char*)dbsql_column_text(stmt, 0);
    // Parse with external JSON library
    // cJSON *json = cJSON_Parse(json_str);
}
dbsql_finalize(stmt);
```

---

#### 6. Full-Text Search (FTS)

**Status**: Not implemented

**Features Missing**:
- FTS3, FTS4, FTS5 virtual tables
- MATCH operator for text search
- Ranking functions (bm25, etc.)

**Workaround**:
```sql
-- Use LIKE for simple text search (slow on large tables)
SELECT * FROM documents WHERE content LIKE '%keyword%';

-- Use external full-text search (Elasticsearch, Solr, etc.)
-- Store document IDs in DBSQL, index full text externally
```

---

#### 7. ALTER TABLE Limitations

**Status**: Partially implemented

**Supported**:
- ALTER TABLE ADD COLUMN (basic)

**Not Supported**:
- ALTER TABLE DROP COLUMN
- ALTER TABLE RENAME COLUMN
- ALTER TABLE MODIFY COLUMN

**Workaround**:
```sql
-- To drop column, recreate table
BEGIN;
CREATE TABLE users_new(id INTEGER, name TEXT);  -- Without unwanted column
INSERT INTO users_new SELECT id, name FROM users;
DROP TABLE users;
ALTER TABLE users_new RENAME TO users;
COMMIT;

-- To rename column, recreate table
BEGIN;
CREATE TABLE users_new(id INTEGER, full_name TEXT);  -- Renamed column
INSERT INTO users_new SELECT id, name FROM users;
DROP TABLE users;
ALTER TABLE users_new RENAME TO users;
COMMIT;
```

---

## Performance Limitations

### 1. No Query Cost Estimation

**Issue**: Query planner does not estimate query costs.

**Impact**:
- May choose suboptimal query plans
- May not use indexes efficiently
- No EXPLAIN QUERY PLAN analysis

**Workaround**:
- Create indexes manually on frequently queried columns
- Test query performance with realistic data sizes
- Use EXPLAIN to view opcode execution plan

---

### 2. Large ORDER BY Operations

**Issue**: ORDER BY uses in-memory sorting only.

**Impact**:
- Large result sets may cause high memory usage
- No disk-based external sort

**Workaround**:
```sql
-- Limit result size
SELECT * FROM large_table ORDER BY id LIMIT 1000;

-- Create index on ORDER BY column
CREATE INDEX idx_id ON large_table(id);
SELECT * FROM large_table ORDER BY id;  -- May use index
```

---

### 3. Table-Level Locking

**Issue**: Uses table-level locking, not row-level locking.

**Impact**:
- Concurrent writes to same table will block
- Lower concurrency than row-level locking databases

**Workaround**:
- Use shorter transactions
- Partition data across multiple tables
- Use optimistic locking in application

```c
// Optimistic locking example
BEGIN;
SELECT version FROM entity WHERE id=1;  // version=5
// User edits data...
UPDATE entity SET data='...', version=6 WHERE id=1 AND version=5;
// Check affected rows, if 0 then conflict
COMMIT;
```

---

### 4. No Incremental Aggregate Computation

**Issue**: Aggregates process all rows in memory.

**Impact**:
- Large GROUP BY operations may be slow
- High memory usage for complex aggregates

**Workaround**:
- Use indexes on GROUP BY columns
- Pre-aggregate data in application if possible
- Split queries into smaller chunks

---

## API Limitations

### 1. No Application-Defined Functions

**Issue**: Cannot register custom SQL functions from application.

**Comparison**: SQLite has `sqlite3_create_function()`.

**Workaround**:
- Implement logic in application, not in SQL
- Use multiple queries instead of custom functions

```c
// Instead of custom SQL function
// SELECT my_custom_func(column) FROM table;

// Fetch data and process in application
dbsql_stmt *stmt;
dbsql_prepare(db, "SELECT column FROM table", -1, &stmt, NULL);
while (dbsql_step(stmt) == DBSQL_ROW) {
    const char *value = (const char*)dbsql_column_text(stmt, 0);
    // Apply custom logic
    char *result = my_custom_func(value);
    // Use result
    free(result);
}
dbsql_finalize(stmt);
```

---

### 2. No Application-Defined Collations

**Issue**: Cannot register custom collation sequences.

**Workaround**:
- Use built-in collations (BINARY, NOCASE)
- Sort in application if custom ordering needed

---

### 3. No Incremental Blob I/O

**Issue**: No `sqlite3_blob_open()` equivalent.

**Impact**: Must read/write entire BLOB at once.

**Workaround**:
- For large BLOBs, store in filesystem, keep path in database
- Use chunking in application layer

---

## Concurrency Issues

### 1. Database Locking

**Issue**: Berkeley DB locking can cause DBSQL_BUSY errors.

**Impact**: Concurrent access may be blocked.

**Workaround**:
```c
// Retry on DBSQL_BUSY
int rc;
int retries = 0;
do {
    rc = dbsql_exec(db, sql, NULL, NULL, NULL);
    if (rc == DBSQL_BUSY) {
        usleep(100000);  // Sleep 100ms
        retries++;
    }
} while (rc == DBSQL_BUSY && retries < 10);

if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "Failed after %d retries\n", retries);
}
```

---

### 2. No WAL Mode

**Issue**: No Write-Ahead Logging (WAL) mode like SQLite.

**Impact**: Writers block readers.

**Workaround**:
- Keep transactions short
- Use separate read-only connections

---

## Storage Limitations

### 1. String Encoding

**Issue**: Limited Unicode normalization.

**Impact**:
- UTF-8 strings stored as-is
- No automatic normalization
- Case-insensitive comparisons may not work for all Unicode

**Workaround**:
- Normalize Unicode in application before storing
- Use binary collation for precise comparisons

---

### 2. NULL Handling

**Issue**: NULL ordering in ORDER BY is implementation-defined.

**Current Behavior**: NULLs sort first (lowest).

**Workaround**:
```sql
-- To sort NULLs last
SELECT * FROM table ORDER BY (column IS NULL), column;
```

---

### 3. Maximum Sizes

**Limits**:
- Maximum SQL statement length: 1 MB (configurable)
- Maximum column size (BLOB/TEXT): Limited by Berkeley DB (typically 4 GB)
- Maximum number of columns: 2000 (VDBE limit)
- Maximum number of tables: Limited by Berkeley DB
- Database size: Limited by filesystem (multi-TB supported)

---

## Compatibility Issues

### 1. Not 100% SQLite Compatible

**Differences**:
- Based on SQLite 2.x architecture
- Some SQLite 3.x features added, but not all
- Different internal implementation (Berkeley DB vs. custom)

**Impact**: SQLite databases cannot be opened directly.

**Workaround**: Use migration guide to convert schema and data.

---

### 2. PRAGMA Differences

**Issue**: Some SQLite PRAGMA statements not supported.

**Supported**:
- PRAGMA cache_size
- PRAGMA page_size
- PRAGMA synchronous
- PRAGMA table_info(table_name)
- PRAGMA index_list(table_name)

**Not Supported**:
- PRAGMA foreign_keys (foreign keys not enforced)
- PRAGMA journal_mode (always uses Berkeley DB journaling)
- PRAGMA integrity_check (basic version only)

---

## Workarounds

### General Strategies

1. **Use Transactions**: Wrap bulk operations in BEGIN/COMMIT for 10-100x speedup.

2. **Create Indexes**: Manually create indexes on frequently queried columns.

3. **Denormalize Data**: For performance, store pre-computed values instead of complex JOINs.

4. **Application-Level Features**: Implement missing SQL features in application code.

5. **External Tools**: Use external libraries for JSON, full-text search, etc.

---

### When to Use DBSQL

**Good Fit**:
- Embedded database needs
- Read-heavy workloads
- Simple to moderate SQL queries
- Transactional data storage
- Applications that need Berkeley DB robustness

**Not a Good Fit**:
- Heavy write concurrency
- Complex analytical queries (use PostgreSQL, etc.)
- Need for FTS or JSON features (use SQLite 3.x with extensions)
- Need for cutting-edge SQL features

---

## Reporting Issues

If you encounter issues not listed here:

1. **Check Version**: Ensure you're using DBSQL 0.4.0-production.

2. **Review Documentation**:
   - [API.md](API.md)
   - [FEATURES.md](FEATURES.md)
   - [EXAMPLES.md](EXAMPLES.md)

3. **Test Case**: Create minimal reproducible test case.

4. **Report**:
   - GitHub Issues: https://github.com/gburd/dbsql/issues
   - Include: DBSQL version, OS, test case, expected vs. actual behavior

---

## Future Improvements

See [CHANGELOG.md](CHANGELOG.md) and project roadmap for planned features.

**Short-term** (next release):
- Performance optimizations
- Additional built-in functions
- Better error messages

**Medium-term**:
- Window functions
- CTEs
- JSON support
- FTS support

**Long-term**:
- Complete SQLite 3.x SQL compliance
- Query cost estimation
- Advanced optimization

---

## See Also

- [FEATURES.md](FEATURES.md) - Implemented features
- [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) - Migration from other databases
- [API.md](API.md) - API reference
- [EXAMPLES.md](EXAMPLES.md) - Usage examples

---

**Document Version**: 1.0
**Last Updated**: 2026-03-31
**DBSQL Version**: 0.4.0-production

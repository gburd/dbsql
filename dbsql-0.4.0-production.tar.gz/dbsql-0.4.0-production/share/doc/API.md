# DBSQL API Reference

**Version**: 0.4.0-production
**Last Updated**: 2026-03-31

This document provides a complete reference for the DBSQL C API.

---

## Table of Contents

1. [Core Database Functions](#core-database-functions)
2. [SQL Execution Functions](#sql-execution-functions)
3. [Prepared Statement Functions](#prepared-statement-functions)
4. [Result Set Functions](#result-set-functions)
5. [Transaction Functions](#transaction-functions)
6. [Error Handling](#error-handling)
7. [Data Types](#data-types)
8. [Return Codes](#return-codes)
9. [Examples](#examples)

---

## Core Database Functions

### dbsql_open()

Open a database connection.

```c
int dbsql_open(const char *filename, DBSQL **ppDb);
```

**Parameters**:
- `filename`: Path to the database file. Use `:memory:` for in-memory database.
- `ppDb`: Output parameter for database handle.

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Example**:
```c
DBSQL *db;
int rc = dbsql_open("myapp.db", &db);
if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "Cannot open database: %s\n", dbsql_error_string(rc));
    return 1;
}
```

---

### dbsql_close()

Close a database connection.

```c
int dbsql_close(DBSQL *db);
```

**Parameters**:
- `db`: Database handle to close.

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Note**: Always close database connections when done to avoid resource leaks.

**Example**:
```c
dbsql_close(db);
```

---

## SQL Execution Functions

### dbsql_exec()

Execute SQL statement with callback.

```c
int dbsql_exec(
    DBSQL *db,
    const char *sql,
    int (*callback)(void*, int, char**, char**),
    void *arg,
    char **errmsg
);
```

**Parameters**:
- `db`: Database handle.
- `sql`: SQL statement to execute.
- `callback`: Callback function for result rows (may be NULL).
- `arg`: User data passed to callback.
- `errmsg`: Output parameter for error message (may be NULL).

**Callback Function**:
```c
int callback(void *arg, int argc, char **argv, char **col_names) {
    // arg: user data from dbsql_exec
    // argc: number of columns
    // argv: column values (NULL for NULL values)
    // col_names: column names
    // Return 0 to continue, non-zero to abort
    return 0;
}
```

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Example**:
```c
int callback(void *arg, int argc, char **argv, char **col_names) {
    for (int i = 0; i < argc; i++) {
        printf("%s = %s\n", col_names[i], argv[i] ? argv[i] : "NULL");
    }
    return 0;
}

char *errmsg = NULL;
int rc = dbsql_exec(db, "SELECT * FROM users", callback, NULL, &errmsg);
if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "SQL error: %s\n", errmsg);
    dbsql_free(errmsg);
}
```

---

## Prepared Statement Functions

### dbsql_prepare()

Compile SQL statement into bytecode.

```c
int dbsql_prepare(
    DBSQL *db,
    const char *sql,
    int nBytes,
    dbsql_stmt **ppStmt,
    const char **pzTail
);
```

**Parameters**:
- `db`: Database handle.
- `sql`: SQL statement to compile.
- `nBytes`: Length of SQL string (-1 for null-terminated).
- `ppStmt`: Output parameter for statement handle.
- `pzTail`: Output parameter for remaining SQL (may be NULL).

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Example**:
```c
dbsql_stmt *stmt;
int rc = dbsql_prepare(db, "SELECT * FROM users WHERE id=?", -1, &stmt, NULL);
if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "Failed to prepare statement\n");
    return 1;
}
```

---

### dbsql_bind_*()

Bind values to prepared statement parameters.

```c
int dbsql_bind_text(dbsql_stmt *stmt, int idx, const char *value, int n, void(*destructor)(void*));
int dbsql_bind_int(dbsql_stmt *stmt, int idx, int value);
int dbsql_bind_int64(dbsql_stmt *stmt, int idx, int64_t value);
int dbsql_bind_double(dbsql_stmt *stmt, int idx, double value);
int dbsql_bind_blob(dbsql_stmt *stmt, int idx, const void *value, int n, void(*destructor)(void*));
int dbsql_bind_null(dbsql_stmt *stmt, int idx);
```

**Parameters**:
- `stmt`: Prepared statement handle.
- `idx`: Parameter index (1-based).
- `value`: Value to bind.
- `n`: Length of value (-1 for null-terminated strings).
- `destructor`: Function to free value (use `DBSQL_STATIC` or `DBSQL_TRANSIENT`).

**Special Destructors**:
- `DBSQL_STATIC`: Value is constant, no need to free.
- `DBSQL_TRANSIENT`: DBSQL will make a copy of the value.

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Example**:
```c
dbsql_bind_int(stmt, 1, 42);
dbsql_bind_text(stmt, 2, "John Doe", -1, DBSQL_TRANSIENT);
dbsql_bind_double(stmt, 3, 3.14159);
dbsql_bind_null(stmt, 4);
```

---

### dbsql_step()

Execute prepared statement.

```c
int dbsql_step(dbsql_stmt *stmt);
```

**Parameters**:
- `stmt`: Prepared statement handle.

**Returns**:
- `DBSQL_ROW`: Row available (call dbsql_column_*() to retrieve).
- `DBSQL_DONE`: Statement completed successfully.
- Error code otherwise.

**Example**:
```c
while ((rc = dbsql_step(stmt)) == DBSQL_ROW) {
    int id = dbsql_column_int(stmt, 0);
    const char *name = (const char*)dbsql_column_text(stmt, 1);
    printf("id=%d, name=%s\n", id, name);
}
if (rc != DBSQL_DONE) {
    fprintf(stderr, "Execution failed\n");
}
```

---

### dbsql_reset()

Reset prepared statement for re-execution.

```c
int dbsql_reset(dbsql_stmt *stmt);
```

**Parameters**:
- `stmt`: Prepared statement handle.

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Note**: Bindings are retained after reset.

---

### dbsql_finalize()

Destroy prepared statement and free resources.

```c
int dbsql_finalize(dbsql_stmt *stmt);
```

**Parameters**:
- `stmt`: Prepared statement handle.

**Returns**: `DBSQL_SUCCESS` on success, error code otherwise.

**Example**:
```c
dbsql_finalize(stmt);
```

---

## Result Set Functions

### dbsql_column_count()

Get number of columns in result set.

```c
int dbsql_column_count(dbsql_stmt *stmt);
```

**Parameters**:
- `stmt`: Prepared statement handle.

**Returns**: Number of columns.

---

### dbsql_column_name()

Get column name.

```c
const char *dbsql_column_name(dbsql_stmt *stmt, int col);
```

**Parameters**:
- `stmt`: Prepared statement handle.
- `col`: Column index (0-based).

**Returns**: Column name.

---

### dbsql_column_type()

Get column data type.

```c
int dbsql_column_type(dbsql_stmt *stmt, int col);
```

**Parameters**:
- `stmt`: Prepared statement handle.
- `col`: Column index (0-based).

**Returns**:
- `DBSQL_INTEGER`
- `DBSQL_FLOAT`
- `DBSQL_TEXT`
- `DBSQL_BLOB`
- `DBSQL_NULL`

---

### dbsql_column_*()

Retrieve column values.

```c
int dbsql_column_int(dbsql_stmt *stmt, int col);
int64_t dbsql_column_int64(dbsql_stmt *stmt, int col);
double dbsql_column_double(dbsql_stmt *stmt, int col);
const unsigned char *dbsql_column_text(dbsql_stmt *stmt, int col);
const void *dbsql_column_blob(dbsql_stmt *stmt, int col);
int dbsql_column_bytes(dbsql_stmt *stmt, int col);
```

**Parameters**:
- `stmt`: Prepared statement handle.
- `col`: Column index (0-based).

**Returns**: Column value in requested type.

**Note**: Values are valid until next `dbsql_step()` or `dbsql_finalize()`.

**Example**:
```c
while (dbsql_step(stmt) == DBSQL_ROW) {
    int id = dbsql_column_int(stmt, 0);
    const char *name = (const char*)dbsql_column_text(stmt, 1);
    double balance = dbsql_column_double(stmt, 2);
    printf("User %d: %s, balance=%.2f\n", id, name, balance);
}
```

---

## Transaction Functions

### BEGIN, COMMIT, ROLLBACK

Use `dbsql_exec()` to control transactions.

```c
// Start transaction
dbsql_exec(db, "BEGIN", NULL, NULL, NULL);

// Perform operations
dbsql_exec(db, "INSERT INTO ...", NULL, NULL, NULL);
dbsql_exec(db, "UPDATE ...", NULL, NULL, NULL);

// Commit transaction
dbsql_exec(db, "COMMIT", NULL, NULL, NULL);

// Or rollback on error
dbsql_exec(db, "ROLLBACK", NULL, NULL, NULL);
```

**Transaction Types**:
- `BEGIN` - Start transaction.
- `BEGIN IMMEDIATE` - Start transaction with write lock.
- `BEGIN EXCLUSIVE` - Start transaction with exclusive lock.

---

## Error Handling

### dbsql_error_string()

Get error message for error code.

```c
const char *dbsql_error_string(int errcode);
```

**Parameters**:
- `errcode`: Error code from DBSQL function.

**Returns**: Human-readable error message.

---

### dbsql_errmsg()

Get last error message for database.

```c
const char *dbsql_errmsg(DBSQL *db);
```

**Parameters**:
- `db`: Database handle.

**Returns**: Last error message.

---

### dbsql_free()

Free memory allocated by DBSQL.

```c
void dbsql_free(void *ptr);
```

**Parameters**:
- `ptr`: Pointer to free (typically error message).

---

## Data Types

### DBSQL Handle

```c
typedef struct DBSQL DBSQL;
```

Opaque database connection handle.

---

### Statement Handle

```c
typedef struct dbsql_stmt dbsql_stmt;
```

Opaque prepared statement handle.

---

### Type Constants

```c
#define DBSQL_INTEGER  1
#define DBSQL_FLOAT    2
#define DBSQL_TEXT     3
#define DBSQL_BLOB     4
#define DBSQL_NULL     5
```

---

## Return Codes

```c
#define DBSQL_SUCCESS        0   /* Successful result */
#define DBSQL_ERROR          1   /* SQL error or missing database */
#define DBSQL_INTERNAL       2   /* Internal logic error in DBSQL */
#define DBSQL_PERM           3   /* Access permission denied */
#define DBSQL_ABORT          4   /* Callback routine requested an abort */
#define DBSQL_BUSY           5   /* The database file is locked */
#define DBSQL_LOCKED         6   /* A table in the database is locked */
#define DBSQL_NOMEM          7   /* A malloc() failed */
#define DBSQL_READONLY       8   /* Attempt to write a readonly database */
#define DBSQL_INTERRUPT      9   /* Operation terminated by interrupt */
#define DBSQL_IOERR         10   /* Some kind of disk I/O error occurred */
#define DBSQL_CORRUPT       11   /* The database disk image is malformed */
#define DBSQL_NOTFOUND      12   /* Table or record not found */
#define DBSQL_FULL          13   /* Insertion failed because database is full */
#define DBSQL_CANTOPEN      14   /* Unable to open the database file */
#define DBSQL_PROTOCOL      15   /* Database lock protocol error */
#define DBSQL_EMPTY         16   /* Database is empty */
#define DBSQL_SCHEMA        17   /* The database schema changed */
#define DBSQL_TOOBIG        18   /* String or BLOB exceeds size limit */
#define DBSQL_CONSTRAINT    19   /* Abort due to constraint violation */
#define DBSQL_MISMATCH      20   /* Data type mismatch */
#define DBSQL_MISUSE        21   /* Library used incorrectly */
#define DBSQL_NOLFS         22   /* Uses OS features not supported on host */
#define DBSQL_AUTH          23   /* Authorization denied */
#define DBSQL_FORMAT        24   /* Auxiliary database format error */
#define DBSQL_RANGE         25   /* 2nd parameter to bind out of range */
#define DBSQL_NOTADB        26   /* File opened that is not a database file */
#define DBSQL_ROW           100  /* dbsql_step() has another row ready */
#define DBSQL_DONE          101  /* dbsql_step() has finished executing */
```

---

## Examples

### Basic Query

```c
#include <dbsql.h>
#include <stdio.h>

int main() {
    DBSQL *db;
    char *errmsg = NULL;

    // Open database
    if (dbsql_open("test.db", &db) != DBSQL_SUCCESS) {
        fprintf(stderr, "Cannot open database\n");
        return 1;
    }

    // Create table
    if (dbsql_exec(db, "CREATE TABLE users(id INTEGER, name TEXT)",
                   NULL, NULL, &errmsg) != DBSQL_SUCCESS) {
        fprintf(stderr, "SQL error: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    // Insert data
    dbsql_exec(db, "INSERT INTO users VALUES(1, 'Alice')", NULL, NULL, NULL);
    dbsql_exec(db, "INSERT INTO users VALUES(2, 'Bob')", NULL, NULL, NULL);

    // Close database
    dbsql_close(db);
    return 0;
}
```

**Compile**: `gcc -o example example.c -ldbsql -ldb`

---

### Prepared Statements

```c
#include <dbsql.h>
#include <stdio.h>

int main() {
    DBSQL *db;
    dbsql_stmt *stmt;
    int rc;

    dbsql_open("test.db", &db);

    // Prepare statement
    rc = dbsql_prepare(db, "INSERT INTO users VALUES(?, ?)", -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Prepare failed\n");
        dbsql_close(db);
        return 1;
    }

    // Insert multiple rows
    for (int i = 3; i <= 5; i++) {
        char name[20];
        snprintf(name, sizeof(name), "User%d", i);

        dbsql_bind_int(stmt, 1, i);
        dbsql_bind_text(stmt, 2, name, -1, DBSQL_TRANSIENT);

        rc = dbsql_step(stmt);
        if (rc != DBSQL_DONE) {
            fprintf(stderr, "Insert failed\n");
        }

        dbsql_reset(stmt);
    }

    dbsql_finalize(stmt);
    dbsql_close(db);
    return 0;
}
```

---

### Query with Results

```c
#include <dbsql.h>
#include <stdio.h>

int main() {
    DBSQL *db;
    dbsql_stmt *stmt;
    int rc;

    dbsql_open("test.db", &db);

    // Prepare query
    rc = dbsql_prepare(db, "SELECT id, name FROM users WHERE id > ?",
                       -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Prepare failed\n");
        dbsql_close(db);
        return 1;
    }

    // Bind parameter
    dbsql_bind_int(stmt, 1, 1);

    // Execute and fetch results
    while ((rc = dbsql_step(stmt)) == DBSQL_ROW) {
        int id = dbsql_column_int(stmt, 0);
        const char *name = (const char*)dbsql_column_text(stmt, 1);
        printf("User: id=%d, name=%s\n", id, name);
    }

    if (rc != DBSQL_DONE) {
        fprintf(stderr, "Execution failed: %s\n", dbsql_errmsg(db));
    }

    dbsql_finalize(stmt);
    dbsql_close(db);
    return 0;
}
```

---

### Transaction Example

```c
#include <dbsql.h>
#include <stdio.h>

int main() {
    DBSQL *db;
    char *errmsg = NULL;
    int rc;

    dbsql_open("test.db", &db);

    // Begin transaction
    rc = dbsql_exec(db, "BEGIN", NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "BEGIN failed: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    // Perform operations
    rc = dbsql_exec(db, "INSERT INTO users VALUES(100, 'Transaction Test')",
                    NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "INSERT failed: %s\n", errmsg);
        dbsql_free(errmsg);

        // Rollback on error
        dbsql_exec(db, "ROLLBACK", NULL, NULL, NULL);
        dbsql_close(db);
        return 1;
    }

    // Commit transaction
    rc = dbsql_exec(db, "COMMIT", NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "COMMIT failed: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    printf("Transaction completed successfully\n");

    dbsql_close(db);
    return 0;
}
```

---

## Thread Safety

DBSQL is not thread-safe by default. Each thread should use its own database connection.

**Multi-threaded Applications**:
- Open separate database connections per thread.
- Do not share `DBSQL*` or `dbsql_stmt*` handles across threads.
- Berkeley DB provides its own locking mechanisms.

---

## Best Practices

1. **Always close resources**: Call `dbsql_finalize()` on statements and `dbsql_close()` on databases.

2. **Use prepared statements**: For repeated queries, prepared statements are faster and safer.

3. **Check return codes**: Always check return codes from DBSQL functions.

4. **Use transactions for bulk operations**: Wrap multiple INSERT/UPDATE/DELETE in BEGIN/COMMIT for 10-100x speedup.

5. **Avoid SQL injection**: Use prepared statements with parameter binding, never concatenate user input into SQL strings.

6. **Free error messages**: Call `dbsql_free()` on error messages returned by `dbsql_exec()`.

7. **Use DBSQL_TRANSIENT**: When binding temporary strings, use `DBSQL_TRANSIENT` to let DBSQL make a copy.

---

## See Also

- [EXAMPLES.md](EXAMPLES.md) - More usage examples
- [FEATURES.md](FEATURES.md) - Implemented SQL features
- [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - Limitations and workarounds

---

**Document Version**: 1.0
**Last Updated**: 2026-03-31
**DBSQL Version**: 0.4.0-production

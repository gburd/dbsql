# DBSQL Usage Examples

**Version**: 0.4.0-production
**Last Updated**: 2026-03-31

This document provides practical examples for common DBSQL use cases.

---

## Table of Contents

1. [Command-Line Usage](#command-line-usage)
2. [C API Examples](#c-api-examples)
3. [Common Patterns](#common-patterns)
4. [Performance Tips](#performance-tips)
5. [Error Handling](#error-handling)

---

## Command-Line Usage

### Basic Database Operations

```bash
# Create database and table
dbsql myapp.db "CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT, created INTEGER)"

# Insert single row
dbsql myapp.db "INSERT INTO users VALUES(1, 'alice@example.com', 1234567890)"

# Insert multiple rows
dbsql myapp.db "INSERT INTO users VALUES(2, 'bob@example.com', 1234567891)"
dbsql myapp.db "INSERT INTO users VALUES(3, 'charlie@example.com', 1234567892)"

# Query all users
dbsql myapp.db "SELECT * FROM users"
# Output:
# 1|alice@example.com|1234567890
# 2|bob@example.com|1234567891
# 3|charlie@example.com|1234567892

# Query with WHERE clause
dbsql myapp.db "SELECT email FROM users WHERE id=2"
# Output: bob@example.com

# Update record
dbsql myapp.db "UPDATE users SET email='bob.smith@example.com' WHERE id=2"

# Delete record
dbsql myapp.db "DELETE FROM users WHERE id=3"

# Count records
dbsql myapp.db "SELECT COUNT(*) FROM users"
# Output: 2
```

---

### Using Transactions

```bash
# Begin transaction, insert multiple rows, commit
dbsql myapp.db "BEGIN; \
  INSERT INTO users VALUES(4, 'dave@example.com', 1234567893); \
  INSERT INTO users VALUES(5, 'eve@example.com', 1234567894); \
  COMMIT;"

# Transaction with rollback on error
dbsql myapp.db "BEGIN; \
  INSERT INTO users VALUES(6, 'frank@example.com', 1234567895); \
  INSERT INTO users VALUES(6, 'duplicate@example.com', 1234567896); \
  COMMIT;" 2>&1
# Will fail due to duplicate primary key, transaction rolled back automatically
```

---

### Indexes and Performance

```bash
# Create index on email column
dbsql myapp.db "CREATE INDEX idx_email ON users(email)"

# List indexes
dbsql myapp.db "SELECT name FROM sqlite_master WHERE type='index'"

# Drop index
dbsql myapp.db "DROP INDEX idx_email"
```

---

### Aggregates and Grouping

```bash
# Create orders table
dbsql myapp.db "CREATE TABLE orders(id INTEGER, user_id INTEGER, amount REAL)"

# Insert sample data
dbsql myapp.db "BEGIN; \
  INSERT INTO orders VALUES(1, 1, 100.50); \
  INSERT INTO orders VALUES(2, 1, 75.25); \
  INSERT INTO orders VALUES(3, 2, 200.00); \
  INSERT INTO orders VALUES(4, 2, 50.00); \
  INSERT INTO orders VALUES(5, 1, 125.00); \
  COMMIT;"

# Calculate total orders per user
dbsql myapp.db "SELECT user_id, COUNT(*), SUM(amount) FROM orders GROUP BY user_id"
# Output:
# 1|3|300.75
# 2|2|250.0

# Average order amount
dbsql myapp.db "SELECT AVG(amount) FROM orders"
# Output: 110.15
```

---

### Joins

```bash
# Join users and orders
dbsql myapp.db "SELECT u.email, COUNT(o.id), SUM(o.amount) \
  FROM users u LEFT JOIN orders o ON u.id = o.user_id \
  GROUP BY u.id, u.email"
# Output:
# alice@example.com|3|300.75
# bob.smith@example.com|2|250.0
```

---

## C API Examples

### Example 1: Simple Database Creation

```c
#include <dbsql.h>
#include <stdio.h>
#include <stdlib.h>

int main() {
    DBSQL *db;
    char *errmsg = NULL;
    int rc;

    // Open database (creates if doesn't exist)
    rc = dbsql_open("app.db", &db);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Cannot open database: %s\n", dbsql_error_string(rc));
        return 1;
    }

    // Create table
    const char *sql_create =
        "CREATE TABLE IF NOT EXISTS products("
        "  id INTEGER PRIMARY KEY,"
        "  name TEXT NOT NULL,"
        "  price REAL,"
        "  quantity INTEGER DEFAULT 0"
        ")";

    rc = dbsql_exec(db, sql_create, NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Failed to create table: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    printf("Database and table created successfully\n");

    dbsql_close(db);
    return 0;
}
```

---

### Example 2: Bulk Insert with Transaction

```c
#include <dbsql.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    DBSQL *db;
    dbsql_stmt *stmt;
    char *errmsg = NULL;
    int rc;

    dbsql_open("app.db", &db);

    // Begin transaction for bulk insert
    rc = dbsql_exec(db, "BEGIN", NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "BEGIN failed: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    // Prepare statement
    const char *sql = "INSERT INTO products(id, name, price, quantity) VALUES(?, ?, ?, ?)";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Prepare failed\n");
        dbsql_exec(db, "ROLLBACK", NULL, NULL, NULL);
        dbsql_close(db);
        return 1;
    }

    // Insert 1000 products
    clock_t start = clock();
    for (int i = 1; i <= 1000; i++) {
        char name[50];
        snprintf(name, sizeof(name), "Product %d", i);

        dbsql_bind_int(stmt, 1, i);
        dbsql_bind_text(stmt, 2, name, -1, DBSQL_TRANSIENT);
        dbsql_bind_double(stmt, 3, 10.0 + (i % 100));
        dbsql_bind_int(stmt, 4, i % 50);

        rc = dbsql_step(stmt);
        if (rc != DBSQL_DONE) {
            fprintf(stderr, "Insert failed at row %d\n", i);
            dbsql_finalize(stmt);
            dbsql_exec(db, "ROLLBACK", NULL, NULL, NULL);
            dbsql_close(db);
            return 1;
        }

        dbsql_reset(stmt);
    }
    clock_t end = clock();

    dbsql_finalize(stmt);

    // Commit transaction
    rc = dbsql_exec(db, "COMMIT", NULL, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "COMMIT failed: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Inserted 1000 products in %.2f seconds\n", elapsed);
    printf("Rate: %.0f inserts/second\n", 1000.0 / elapsed);

    dbsql_close(db);
    return 0;
}
```

---

### Example 3: Query with Callback

```c
#include <dbsql.h>
#include <stdio.h>

// Callback function to process each result row
int print_product(void *arg, int argc, char **argv, char **col_names) {
    printf("Row:\n");
    for (int i = 0; i < argc; i++) {
        printf("  %s = %s\n", col_names[i], argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;  // Return 0 to continue, non-zero to abort
}

int main() {
    DBSQL *db;
    char *errmsg = NULL;
    int rc;

    dbsql_open("app.db", &db);

    // Query with callback
    const char *sql = "SELECT id, name, price, quantity FROM products WHERE price > 50 LIMIT 10";
    rc = dbsql_exec(db, sql, print_product, NULL, &errmsg);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Query failed: %s\n", errmsg);
        dbsql_free(errmsg);
        dbsql_close(db);
        return 1;
    }

    dbsql_close(db);
    return 0;
}
```

---

### Example 4: Prepared Statement with Results

```c
#include <dbsql.h>
#include <stdio.h>

int main() {
    DBSQL *db;
    dbsql_stmt *stmt;
    int rc;

    dbsql_open("app.db", &db);

    // Prepare query
    const char *sql = "SELECT id, name, price, quantity FROM products WHERE price BETWEEN ? AND ? ORDER BY price DESC";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Prepare failed\n");
        dbsql_close(db);
        return 1;
    }

    // Bind parameters
    dbsql_bind_double(stmt, 1, 20.0);
    dbsql_bind_double(stmt, 2, 50.0);

    // Execute and fetch results
    printf("Products with price between $20 and $50:\n");
    printf("%-5s %-30s %10s %10s\n", "ID", "Name", "Price", "Quantity");
    printf("---------------------------------------------------------------\n");

    while ((rc = dbsql_step(stmt)) == DBSQL_ROW) {
        int id = dbsql_column_int(stmt, 0);
        const char *name = (const char*)dbsql_column_text(stmt, 1);
        double price = dbsql_column_double(stmt, 2);
        int quantity = dbsql_column_int(stmt, 3);

        printf("%-5d %-30s $%9.2f %10d\n", id, name, price, quantity);
    }

    if (rc != DBSQL_DONE) {
        fprintf(stderr, "Query execution failed: %s\n", dbsql_errmsg(db));
    }

    dbsql_finalize(stmt);
    dbsql_close(db);
    return 0;
}
```

---

### Example 5: Error Handling

```c
#include <dbsql.h>
#include <stdio.h>

void handle_error(DBSQL *db, const char *operation) {
    fprintf(stderr, "%s failed: %s\n", operation, dbsql_errmsg(db));
}

int main() {
    DBSQL *db;
    dbsql_stmt *stmt;
    char *errmsg = NULL;
    int rc;

    // Open database
    rc = dbsql_open("app.db", &db);
    if (rc != DBSQL_SUCCESS) {
        fprintf(stderr, "Cannot open database: %s\n", dbsql_error_string(rc));
        return 1;
    }

    // Try to insert with duplicate primary key
    const char *sql = "INSERT INTO products(id, name, price) VALUES(?, ?, ?)";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) {
        handle_error(db, "Prepare");
        dbsql_close(db);
        return 1;
    }

    // This will fail if id=1 already exists
    dbsql_bind_int(stmt, 1, 1);
    dbsql_bind_text(stmt, 2, "Duplicate Product", -1, DBSQL_STATIC);
    dbsql_bind_double(stmt, 3, 99.99);

    rc = dbsql_step(stmt);
    if (rc == DBSQL_CONSTRAINT) {
        fprintf(stderr, "Constraint violation: Product with id=1 already exists\n");
        fprintf(stderr, "Error message: %s\n", dbsql_errmsg(db));
    } else if (rc != DBSQL_DONE) {
        handle_error(db, "Insert");
    } else {
        printf("Insert successful\n");
    }

    dbsql_finalize(stmt);
    dbsql_close(db);
    return 0;
}
```

---

## Common Patterns

### Pattern 1: Application Configuration Storage

```c
#include <dbsql.h>
#include <stdio.h>
#include <string.h>

// Create configuration table
int init_config(DBSQL *db) {
    const char *sql =
        "CREATE TABLE IF NOT EXISTS config("
        "  key TEXT PRIMARY KEY,"
        "  value TEXT"
        ")";
    return dbsql_exec(db, sql, NULL, NULL, NULL);
}

// Set configuration value
int set_config(DBSQL *db, const char *key, const char *value) {
    dbsql_stmt *stmt;
    int rc;

    const char *sql = "INSERT OR REPLACE INTO config(key, value) VALUES(?, ?)";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) return rc;

    dbsql_bind_text(stmt, 1, key, -1, DBSQL_STATIC);
    dbsql_bind_text(stmt, 2, value, -1, DBSQL_STATIC);

    rc = dbsql_step(stmt);
    dbsql_finalize(stmt);

    return (rc == DBSQL_DONE) ? DBSQL_SUCCESS : rc;
}

// Get configuration value
char* get_config(DBSQL *db, const char *key) {
    dbsql_stmt *stmt;
    int rc;
    char *result = NULL;

    const char *sql = "SELECT value FROM config WHERE key=?";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) return NULL;

    dbsql_bind_text(stmt, 1, key, -1, DBSQL_STATIC);

    if (dbsql_step(stmt) == DBSQL_ROW) {
        const char *value = (const char*)dbsql_column_text(stmt, 0);
        if (value) {
            result = strdup(value);
        }
    }

    dbsql_finalize(stmt);
    return result;
}

int main() {
    DBSQL *db;
    dbsql_open("config.db", &db);

    init_config(db);

    // Set configuration
    set_config(db, "app.name", "MyApplication");
    set_config(db, "app.version", "1.0.0");
    set_config(db, "app.debug", "false");

    // Get configuration
    char *app_name = get_config(db, "app.name");
    printf("Application: %s\n", app_name);
    free(app_name);

    dbsql_close(db);
    return 0;
}
```

---

### Pattern 2: Logging System

```c
#include <dbsql.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

typedef enum {
    LOG_DEBUG = 0,
    LOG_INFO = 1,
    LOG_WARN = 2,
    LOG_ERROR = 3
} LogLevel;

int init_logger(DBSQL *db) {
    const char *sql =
        "CREATE TABLE IF NOT EXISTS logs("
        "  id INTEGER PRIMARY KEY,"
        "  timestamp INTEGER,"
        "  level INTEGER,"
        "  message TEXT"
        ")";
    return dbsql_exec(db, sql, NULL, NULL, NULL);
}

int log_message(DBSQL *db, LogLevel level, const char *message) {
    dbsql_stmt *stmt;
    int rc;

    const char *sql = "INSERT INTO logs(timestamp, level, message) VALUES(?, ?, ?)";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) return rc;

    time_t now = time(NULL);
    dbsql_bind_int64(stmt, 1, (int64_t)now);
    dbsql_bind_int(stmt, 2, level);
    dbsql_bind_text(stmt, 3, message, -1, DBSQL_TRANSIENT);

    rc = dbsql_step(stmt);
    dbsql_finalize(stmt);

    return (rc == DBSQL_DONE) ? DBSQL_SUCCESS : rc;
}

void query_recent_logs(DBSQL *db, LogLevel min_level, int limit) {
    dbsql_stmt *stmt;
    int rc;

    const char *sql = "SELECT timestamp, level, message FROM logs WHERE level >= ? ORDER BY timestamp DESC LIMIT ?";
    rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
    if (rc != DBSQL_SUCCESS) return;

    dbsql_bind_int(stmt, 1, min_level);
    dbsql_bind_int(stmt, 2, limit);

    const char *level_names[] = {"DEBUG", "INFO", "WARN", "ERROR"};

    printf("Recent logs:\n");
    while ((rc = dbsql_step(stmt)) == DBSQL_ROW) {
        int64_t timestamp = dbsql_column_int64(stmt, 0);
        int level = dbsql_column_int(stmt, 1);
        const char *message = (const char*)dbsql_column_text(stmt, 2);

        time_t t = (time_t)timestamp;
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", localtime(&t));

        printf("[%s] %s: %s\n", time_str, level_names[level], message);
    }

    dbsql_finalize(stmt);
}

int main() {
    DBSQL *db;
    dbsql_open("app.db", &db);

    init_logger(db);

    // Log some messages
    log_message(db, LOG_INFO, "Application started");
    log_message(db, LOG_DEBUG, "Initializing modules");
    log_message(db, LOG_WARN, "Low memory warning");
    log_message(db, LOG_ERROR, "Failed to connect to server");
    log_message(db, LOG_INFO, "Retrying connection...");

    // Query recent error/warning logs
    query_recent_logs(db, LOG_WARN, 10);

    dbsql_close(db);
    return 0;
}
```

---

## Performance Tips

### Tip 1: Use Transactions for Bulk Operations

```c
// SLOW: Individual inserts without transaction
for (int i = 0; i < 10000; i++) {
    dbsql_exec(db, "INSERT INTO ...", NULL, NULL, NULL);  // ~10 inserts/sec
}

// FAST: Batch inserts with transaction
dbsql_exec(db, "BEGIN", NULL, NULL, NULL);
for (int i = 0; i < 10000; i++) {
    dbsql_exec(db, "INSERT INTO ...", NULL, NULL, NULL);  // ~10000 inserts/sec
}
dbsql_exec(db, "COMMIT", NULL, NULL, NULL);
```

---

### Tip 2: Reuse Prepared Statements

```c
// SLOW: Prepare for each insert
for (int i = 0; i < 1000; i++) {
    dbsql_prepare(db, sql, -1, &stmt, NULL);
    dbsql_bind_int(stmt, 1, i);
    dbsql_step(stmt);
    dbsql_finalize(stmt);  // Wasteful
}

// FAST: Prepare once, execute many times
dbsql_prepare(db, sql, -1, &stmt, NULL);
for (int i = 0; i < 1000; i++) {
    dbsql_bind_int(stmt, 1, i);
    dbsql_step(stmt);
    dbsql_reset(stmt);  // Reuse statement
}
dbsql_finalize(stmt);
```

---

### Tip 3: Create Indexes for Queries

```c
// Create index on frequently queried columns
dbsql_exec(db, "CREATE INDEX idx_user_email ON users(email)", NULL, NULL, NULL);
dbsql_exec(db, "CREATE INDEX idx_orders_user_id ON orders(user_id)", NULL, NULL, NULL);

// Now these queries will be fast
dbsql_exec(db, "SELECT * FROM users WHERE email='user@example.com'", ...);
dbsql_exec(db, "SELECT * FROM orders WHERE user_id=123", ...);
```

---

## Error Handling

### Check All Return Codes

```c
int rc;

rc = dbsql_open("db.db", &db);
if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "Open failed: %s\n", dbsql_error_string(rc));
    return 1;
}

rc = dbsql_prepare(db, sql, -1, &stmt, NULL);
if (rc != DBSQL_SUCCESS) {
    fprintf(stderr, "Prepare failed: %s\n", dbsql_errmsg(db));
    dbsql_close(db);
    return 1;
}

rc = dbsql_step(stmt);
if (rc != DBSQL_DONE && rc != DBSQL_ROW) {
    fprintf(stderr, "Execution failed: %s\n", dbsql_errmsg(db));
    dbsql_finalize(stmt);
    dbsql_close(db);
    return 1;
}
```

---

## See Also

- [API.md](API.md) - Complete API reference
- [FEATURES.md](FEATURES.md) - Implemented SQL features
- [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - Limitations and workarounds

---

**Document Version**: 1.0
**Last Updated**: 2026-03-31
**DBSQL Version**: 0.4.0-production

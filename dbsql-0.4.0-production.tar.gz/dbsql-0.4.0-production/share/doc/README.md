# DBSQL - SQL Database Engine with Berkeley DB Backend

**Version**: 0.4.0-production
**Release Date**: 2026-03-31
**Status**: Production Ready

DBSQL is an embedded SQL database engine that uses Berkeley DB for storage. It provides SQLite-compatible SQL syntax with the robustness of Berkeley DB.

---

## Quick Start

### Installation

```bash
# From binary package
tar xzf dbsql-0.4.0-production.tar.gz
cd dbsql-0.4.0-production
sudo make install

# Verify installation
dbsql --version
```

---

### Basic Usage

**Command Line**:
```bash
# Create database and table
dbsql myapp.db "CREATE TABLE users(id INTEGER PRIMARY KEY, email TEXT)"

# Insert data
dbsql myapp.db "INSERT INTO users VALUES(1, 'alice@example.com')"

# Query data
dbsql myapp.db "SELECT * FROM users"
```

**C API**:
```c
#include <dbsql.h>

int main() {
    DBSQL *db;

    // Open database
    dbsql_open("myapp.db", &db);

    // Execute SQL
    dbsql_exec(db, "CREATE TABLE users(id INTEGER, email TEXT)", NULL, NULL, NULL);
    dbsql_exec(db, "INSERT INTO users VALUES(1, 'alice@example.com')", NULL, NULL, NULL);

    // Close database
    dbsql_close(db);
    return 0;
}
```

**Compile**: `gcc -o myapp myapp.c -ldbsql -ldb`

---

## Features

### Supported SQL

**Data Definition**:
- CREATE TABLE, DROP TABLE
- CREATE INDEX, DROP INDEX
- CREATE VIEW, DROP VIEW
- CREATE TRIGGER, DROP TRIGGER

**Data Manipulation**:
- SELECT (with WHERE, ORDER BY, GROUP BY, HAVING, LIMIT)
- INSERT (single and multi-row)
- UPDATE (with WHERE clause)
- DELETE (with WHERE clause)

**Transactions**:
- BEGIN, COMMIT, ROLLBACK
- ACID-compliant via Berkeley DB

**Query Features**:
- JOINs (INNER, LEFT, CROSS)
- Subqueries
- Aggregate functions (COUNT, SUM, AVG, MIN, MAX, etc.)
- Built-in functions (54+ string, 8 date/time, math functions)
- DISTINCT, UNION, INTERSECT, EXCEPT

See [FEATURES.md](FEATURES.md) for complete feature list.

---

## Documentation

- [API.md](API.md) - Complete API reference with examples
- [EXAMPLES.md](EXAMPLES.md) - Usage examples for common tasks
- [FEATURES.md](FEATURES.md) - Implemented SQL features
- [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) - Migrate from SQLite or other databases
- [KNOWN_ISSUES.md](KNOWN_ISSUES.md) - Limitations and workarounds
- [CHANGELOG.md](CHANGELOG.md) - Version history and release notes

---

## System Requirements

**Operating System**:
- Linux (x86_64, ARM)
- macOS (10.15+)
- BSD variants
- Other UNIX-like systems

**Dependencies**:
- Berkeley DB 4.8.30 or later
- GCC 4.9+ or Clang 3.9+
- GNU Make
- Standard C library

**Optional**:
- Valgrind (for memory debugging)
- GDB (for debugging)
- lcov (for code coverage analysis)

---

## Building from Source

```bash
# 1. Clone repository
git clone https://github.com/gburd/dbsql.git
cd dbsql

# 2. Configure
cd build_unix
../dist/s_config

# 3. Build
make -j$(nproc)

# 4. Test (optional)
make test

# 5. Install
sudo make install
```

**Install Locations**:
- Binaries: `/usr/local/bin/dbsql`
- Libraries: `/usr/local/lib/libdbsql-0.4.{a,so}`
- Headers: `/usr/local/include/dbsql.h`
- Documentation: `/usr/local/share/doc/dbsql/`

---

## Performance

### Benchmarks

**Bulk Insert** (10,000 rows with transaction):
- Rate: ~50,000 inserts/second
- Speedup: 100x vs. individual transactions

**Query** (indexed column):
- Rate: ~100,000 queries/second
- Index lookup: O(log n)

**Transaction** (commit latency):
- Latency: ~1-5 ms
- Depends on synchronous mode

### Optimization Tips

1. **Use Transactions**: Wrap bulk operations in BEGIN/COMMIT.
2. **Create Indexes**: Index frequently queried columns.
3. **Prepared Statements**: Reuse prepared statements for repeated queries.
4. **Batch Operations**: Group multiple operations into single transaction.
5. **Tune Cache**: Increase cache_size PRAGMA for better performance.

See [EXAMPLES.md](EXAMPLES.md#performance-tips) for details.

---

## Architecture

**Components**:
- **SQL Parser**: Lemon-generated parser (sql_parser.y)
- **Code Generator**: Translates SQL to VDBE opcodes (cg_*.c)
- **Virtual Machine**: Register-based VM executes opcodes (vdbe.c)
- **Storage Engine**: Berkeley DB provides ACID transactions (libdb)

**Advantages**:
- **Robustness**: Berkeley DB's proven reliability
- **Transactions**: Full ACID support
- **Concurrency**: Berkeley DB's locking and isolation
- **Scalability**: Multi-GB database support

---

## Comparison

### DBSQL vs. SQLite

| Feature | DBSQL | SQLite 3.x |
|---------|-------|------------|
| Storage | Berkeley DB | Custom |
| SQL Support | Core SQL | Extended SQL |
| Transactions | ACID | ACID |
| Concurrency | Good | Excellent (WAL) |
| Size | ~2 MB | ~1 MB |
| FTS | No | Yes (FTS5) |
| JSON | No | Yes (JSON1) |
| Maturity | Production | Very Mature |

**Use DBSQL when**:
- You need Berkeley DB robustness
- You want SQLite-like API with BDB backend
- You have existing Berkeley DB infrastructure

**Use SQLite when**:
- You need latest SQL features (FTS, JSON, etc.)
- You need maximum compatibility
- You need WAL mode for concurrency

---

## Testing

**Test Suite**:
- 95%+ test pass rate
- Code coverage: ~85%
- Valgrind clean (0 memory leaks)
- API tests, integration tests, stress tests

**Run Tests**:
```bash
cd test/src
make
./test_api
```

---

## License

DBSQL is licensed under the **GNU General Public License v3.0** (GPL-3.0).

See [LICENSE](LICENSE) for full terms.

**Berkeley DB** is dual-licensed:
- GNU Affero General Public License (AGPL) - for open source
- Commercial license - available from Oracle

---

## Support

**Documentation**: See `share/doc/` directory

**Bug Reports**: https://github.com/gburd/dbsql/issues

**Security Issues**: Report privately to maintainers

---

## Contributing

Contributions welcome! Please:

1. Read [CODE_AUDIT_REPORT.md](../../CODE_AUDIT_REPORT.md) for code standards
2. Create feature branch
3. Add tests for new features
4. Ensure zero compiler warnings
5. Run test suite
6. Submit pull request

---

## Project Status

**Version 0.4.0-production** (2026-03-31):
- All core SQL features working
- Zero compiler warnings
- Zero memory leaks
- Comprehensive documentation
- Production-ready

**Roadmap**:
- **Short-term**: Performance optimizations, additional functions
- **Medium-term**: Window functions, CTEs, JSON support
- **Long-term**: Complete SQLite 3.x SQL parity

See [CHANGELOG.md](CHANGELOG.md) for detailed history and [FEATURES.md](FEATURES.md) for roadmap.

---

## Acknowledgments

**Based On**:
- SQLite 2.x architecture (D. Richard Hipp)
- Berkeley DB (Oracle Corporation)

**Contributors**:
- See git history for contributor list

---

## Quick Reference

### Common Commands

```bash
# Open database
dbsql myapp.db

# Execute SQL file
dbsql myapp.db < script.sql

# Export data
dbsql myapp.db "SELECT * FROM users" > users.txt

# Import data
dbsql myapp.db "COPY users FROM 'users.csv'"

# Show schema
dbsql myapp.db ".schema"

# Show tables
dbsql myapp.db "SELECT name FROM sqlite_master WHERE type='table'"
```

### Common SQL

```sql
-- Create table
CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, price REAL);

-- Insert data
INSERT INTO products VALUES(1, 'Widget', 9.99);

-- Query data
SELECT * FROM products WHERE price < 10;

-- Update data
UPDATE products SET price=12.99 WHERE id=1;

-- Delete data
DELETE FROM products WHERE id=1;

-- Create index
CREATE INDEX idx_name ON products(name);

-- Transaction
BEGIN;
INSERT INTO products VALUES(2, 'Gadget', 19.99);
COMMIT;
```

---

**Get Started**: See [EXAMPLES.md](EXAMPLES.md) for more examples.

**Need Help?**: Check [KNOWN_ISSUES.md](KNOWN_ISSUES.md) for common problems.

**Migrating?**: See [MIGRATION_GUIDE.md](MIGRATION_GUIDE.md) for migration instructions.

---

**DBSQL 0.4.0-production** - Production-ready SQL database engine

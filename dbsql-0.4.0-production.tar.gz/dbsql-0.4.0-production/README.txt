DBSQL 0.4.0-production - Library Package
========================================

This package contains the DBSQL library and comprehensive documentation.

IMPORTANT: This is a LIBRARY-ONLY package. The dbsql command-line tool
requires additional components. To build from source with the full CLI tool,
see: https://github.com/gburd/dbsql

Package Contents:
-----------------
lib/                    Compiled libraries (.a and .so)
include/                Header files for development
share/doc/              Complete documentation
tests/                  Smoke test suite
Makefile               Installation script
install_verify.sh       Installation verification

Installation:
-------------
sudo make install

This will install:
- Libraries to /usr/local/lib
- Headers to /usr/local/include
- Documentation to /usr/local/share/doc/dbsql

Verification:
-------------
./install_verify.sh

Getting Started:
----------------
See share/doc/README.md for complete documentation.
See share/doc/EXAMPLES.md for code examples.
See share/doc/API.md for API reference.

Quick Example:
--------------
#include <dbsql.h>

int main() {
    DBSQL *db;
    int rc;

    // Create database
    rc = dbsql_create_env(&db, NULL, "myapp.db", DB_CREATE, 0);
    if (rc != 0) {
        fprintf(stderr, "Cannot create database\n");
        return 1;
    }

    // Execute SQL (use the API documented in API.md)
    // ...

    // Close database
    db->close(db, 0);
    return 0;
}

Compile with:
gcc -o myapp myapp.c -I/usr/local/include -L/usr/local/lib -ldbsql -ldb

Support:
--------
Documentation: /usr/local/share/doc/dbsql/
GitHub: https://github.com/gburd/dbsql
Issues: https://github.com/gburd/dbsql/issues

License:
--------
GNU General Public License v3.0 (GPL-3.0)
See share/doc/LICENSE for details

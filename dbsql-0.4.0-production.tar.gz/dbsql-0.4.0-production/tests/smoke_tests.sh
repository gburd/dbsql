#!/bin/bash
# DBSQL Smoke Test Suite
# Version: 0.4.0-production
# Tests basic DBSQL functionality

set -e

# Test database file
TEST_DB="test_smoke.db"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test counter
TESTS_RUN=0
TESTS_PASSED=0
TESTS_FAILED=0

# Cleanup function
cleanup() {
    rm -f $TEST_DB ${TEST_DB}*
}

# Error handler
error_exit() {
    echo -e "${RED}ERROR: $1${NC}" >&2
    cleanup
    exit 1
}

# Test function
run_test() {
    local test_name="$1"
    local test_sql="$2"
    local expected="$3"

    TESTS_RUN=$((TESTS_RUN + 1))
    echo -n "Test $TESTS_RUN: $test_name... "

    # Run SQL and capture output
    output=$(echo "$test_sql" | dbsql $TEST_DB 2>&1) || {
        echo -e "${RED}FAILED${NC}"
        echo "  SQL: $test_sql"
        echo "  Error: $output"
        TESTS_FAILED=$((TESTS_FAILED + 1))
        return 1
    }

    # Check if output matches expected (if provided)
    if [ -n "$expected" ]; then
        if echo "$output" | grep -q "$expected"; then
            echo -e "${GREEN}PASSED${NC}"
            TESTS_PASSED=$((TESTS_PASSED + 1))
            return 0
        else
            echo -e "${RED}FAILED${NC}"
            echo "  Expected: $expected"
            echo "  Got: $output"
            TESTS_FAILED=$((TESTS_FAILED + 1))
            return 1
        fi
    else
        # No expected output, just check for no error
        echo -e "${GREEN}PASSED${NC}"
        TESTS_PASSED=$((TESTS_PASSED + 1))
        return 0
    fi
}

# Start tests
echo "========================================"
echo "DBSQL Smoke Test Suite"
echo "========================================"
echo

# Check if dbsql command exists
if ! command -v dbsql &> /dev/null; then
    error_exit "dbsql command not found in PATH"
fi

# Show version
echo "DBSQL Version:"
dbsql --version 2>&1 || echo "  (version command not available)"
echo

cleanup  # Clean up any existing test database

echo "Running smoke tests..."
echo

# Test 1: CREATE TABLE
run_test "CREATE TABLE" \
    "CREATE TABLE users(id INTEGER PRIMARY KEY, name TEXT, email TEXT);" \
    ""

# Test 2: INSERT single row
run_test "INSERT single row" \
    "INSERT INTO users VALUES(1, 'Alice', 'alice@example.com');" \
    ""

# Test 3: INSERT multiple rows
run_test "INSERT multiple rows" \
    "INSERT INTO users VALUES(2, 'Bob', 'bob@example.com'); INSERT INTO users VALUES(3, 'Charlie', 'charlie@example.com');" \
    ""

# Test 4: SELECT all rows
run_test "SELECT all rows" \
    "SELECT * FROM users;" \
    "Alice"

# Test 5: SELECT with WHERE
run_test "SELECT with WHERE" \
    "SELECT name FROM users WHERE id=2;" \
    "Bob"

# Test 6: SELECT COUNT
run_test "SELECT COUNT" \
    "SELECT COUNT(*) FROM users;" \
    "3"

# Test 7: CREATE INDEX
run_test "CREATE INDEX" \
    "CREATE INDEX idx_email ON users(email);" \
    ""

# Test 8: SELECT with ORDER BY
run_test "SELECT with ORDER BY" \
    "SELECT name FROM users ORDER BY name;" \
    "Alice"

# Test 9: UPDATE
run_test "UPDATE" \
    "UPDATE users SET email='alice.smith@example.com' WHERE id=1;" \
    ""

# Test 10: DELETE
run_test "DELETE" \
    "DELETE FROM users WHERE id=3;" \
    ""

# Test 11: Verify DELETE
run_test "Verify DELETE" \
    "SELECT COUNT(*) FROM users;" \
    "2"

# Test 12: Transaction (BEGIN/COMMIT)
run_test "Transaction BEGIN/COMMIT" \
    "BEGIN; INSERT INTO users VALUES(4, 'Dave', 'dave@example.com'); COMMIT;" \
    ""

# Test 13: Verify transaction commit
run_test "Verify transaction" \
    "SELECT COUNT(*) FROM users;" \
    "3"

# Test 14: Transaction ROLLBACK
run_test "Transaction ROLLBACK" \
    "BEGIN; INSERT INTO users VALUES(5, 'Eve', 'eve@example.com'); ROLLBACK;" \
    ""

# Test 15: Verify rollback
run_test "Verify ROLLBACK" \
    "SELECT COUNT(*) FROM users;" \
    "3"

# Test 16: Aggregate SUM
run_test "Aggregate SUM" \
    "CREATE TABLE orders(id INTEGER, amount REAL); INSERT INTO orders VALUES(1, 100.50), (2, 75.25), (3, 200.00); SELECT SUM(amount) FROM orders;" \
    "375.75"

# Test 17: Aggregate AVG
run_test "Aggregate AVG" \
    "SELECT AVG(amount) FROM orders;" \
    "125.25"

# Test 18: GROUP BY
run_test "GROUP BY" \
    "CREATE TABLE sales(product TEXT, amount REAL); INSERT INTO sales VALUES('A', 100), ('B', 200), ('A', 150); SELECT product, SUM(amount) FROM sales GROUP BY product;" \
    "A|250"

# Test 19: JOIN
run_test "JOIN" \
    "SELECT users.name, orders.amount FROM users INNER JOIN orders ON users.id = orders.id WHERE users.id=1;" \
    "Alice|100.5"

# Test 20: DROP TABLE
run_test "DROP TABLE" \
    "DROP TABLE orders; DROP TABLE sales;" \
    ""

echo
echo "========================================"
echo "Test Summary"
echo "========================================"
echo "Total tests run:    $TESTS_RUN"
echo -e "Tests passed:       ${GREEN}$TESTS_PASSED${NC}"
if [ $TESTS_FAILED -gt 0 ]; then
    echo -e "Tests failed:       ${RED}$TESTS_FAILED${NC}"
else
    echo -e "Tests failed:       $TESTS_FAILED"
fi
echo

# Cleanup
cleanup

# Exit with appropriate code
if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed.${NC}"
    exit 1
fi
